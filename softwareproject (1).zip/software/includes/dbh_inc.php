<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "research";

//creates the connection
$conn = new mysqli($dbServername,$dbUsername, $dbPassword , $dbName );



?>