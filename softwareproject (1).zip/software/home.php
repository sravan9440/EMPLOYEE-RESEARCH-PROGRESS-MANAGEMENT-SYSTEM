<!DOCTYPE html>
<html>
<head>
	<title>HOME</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<style>
		body{
		background: url(wp3191222.jpg);
		
		background-size: cover;
		}
	</style>
</head>
<body>
<div class="topnav">
  <a class="active" href="#home">Home</a>
</div>

<div class="container">
	<div id="content">
		<h1>Research Progress <br> Managment System</h1>
		<br>
		<div class='myDiv'>
			<a  style="margin-right:35px; padding: 14px 28px; font-size: 16px;" href="http://localhost/software/viewhome.php" class="button">View portal</a>
			<a style="margin-left:35px; padding: 14px 28px; font-size: 16px;" class="button" href= "http://localhost/software/facultylogin.php">Faculty portal</a>
		</div>
		<br><br><br>
		<hr>
		<h3>Research progress management system is a platform where the faculty under authorised id's can provide the progress of their research status. On additional to this final year students are provided a portal where they can choose the faculty as their research guides. This management system comes us with a solution for the ease of faculty and the students.</h3>
		<hr>
		<br><br>
	</div>
</div>




<footer>
  <p>Developed by: Ar_Vamshi & Abhinav</p>

</footer>
</body>
</html>